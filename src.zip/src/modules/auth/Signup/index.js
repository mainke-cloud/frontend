import SignupFirebase from './SignupFirebase';

export default SignupFirebase;
