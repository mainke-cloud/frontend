import ForgetPasswordJwtAuth from './ForgetPasswordJwtAuth';

export default ForgetPasswordJwtAuth;
