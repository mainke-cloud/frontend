import React from 'react'

const Content = () => {
  return (
    <div>
      hai
    </div>
  )
}

export default Content
