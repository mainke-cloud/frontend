const languageData = [
  {
    languageId: 'english',
    locale: 'en',
    name: 'English',
  },
];
export default languageData;
