import React from 'react'

const ScanSurat = () => {
  return (
    <div>
      Scan Surat
    </div>
  )
}

export default ScanSurat
