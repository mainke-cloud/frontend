import React from 'react'

const Folder = () => {
  return (
    <div>
      Folder
    </div>
  )
}

export default Folder
