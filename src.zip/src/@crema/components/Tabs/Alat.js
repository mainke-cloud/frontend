import React from 'react'

const Alat = () => {
  return (
    <div>
      Alat
    </div>
  )
}

export default Alat
