import React from 'react'

const Arsip = () => {
  return (
    <div>
      Arsip
    </div>
  )
}

export default Arsip
